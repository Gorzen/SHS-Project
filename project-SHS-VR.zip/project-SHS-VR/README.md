# L’influence du changement de contexte dans la mémoire
Ce projet a été fait dans le cadre du cours SHS _La recherche dans tous ses états_, cours donné en master à l'EPFL. Ce projet a été fait en partenariat avec la [Fondation Artanim](http://artanim.ch/) qui a développé le programme de réalité virtuelle utilisé pour l'expérience.

# Fichiers présent
- rapport.pdf: le rapport décrivant le projet réalisé.
- consent.pdf: Fiche de consentement signé par chaque sujet, garantissant leur anonymat.
- analyse.ipynb: un notebook jupyter basé sur python. C'est avec cela que nous avons conduit les ananalyses sur les données récoltées.
- data/nombres_sujets.csv: fichier csv contenant le nombre de sujets par catégorie de personnes. La catégorie _A_ représente la forêt, la catégorie _B_ le désert. Donc _AA_ signifie un sujet qui passe de l'environnement forêt à forêt, _AB_ de forêt à désert, etc.
- data/results.csv: les résultats de toutes les expériences menées sur nos sujets, en fichier csv. Ce format est tout à fait adéquat pour être importé sur excel un n'importe quel programme de ce genre.
- plots/: dossier contenant les graphiques crées par le notebook python.
